package com.gupaoedu.demo.mvc.action;


//没加注解，控制权不反转，自己管自己
public class TestAction {
}
