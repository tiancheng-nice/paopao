package com.gupaoedu.vip.spring.framework.aop;

/**
 * Created by Tom.
 */
public class GPCglibAopPorxy implements GPAopProxy {
    @Override
    public Object getProxy() {
        return null;
    }

    @Override
    public Object getProxy(ClassLoader classLoader) {
        return null;
    }
}
