package com.gupaoedu.vip.spring.framework.aop.aspect;

/**
 * Created by Tom.
 */

public interface GPAdvice {


}
