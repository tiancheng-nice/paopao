package com.gupaoedu.vip.demo.service;

public interface IAddService {
}
